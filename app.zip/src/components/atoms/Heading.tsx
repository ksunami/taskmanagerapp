import React, { type ReactNode, type ElementType } from 'react';

type HeadingLevel = 'h1' | 'h2' | 'h3' | 'h4' | 'h5' | 'h6';

type Props = {
  as?: HeadingLevel;
  className?: string;
  children: ReactNode;
};

export default function Heading({ as = 'h2', className, children }: Props) {
  const Tag = as as ElementType; 
  return <Tag className={className}>{children}</Tag>;
}